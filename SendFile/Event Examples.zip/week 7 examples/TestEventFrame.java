/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.event.*;
import javax.swing.*;

public class TestEventFrame extends JFrame { // window actions

    public static void main(String[] args) {
        JFrame frame = new TestEventFrame();
        JTextArea lblStatus = new JTextArea();
        lblStatus.setEditable(false);
        frame.add(lblStatus);
        frame.setSize(800, 800);
        frame.addWindowListener(new MyWindowListener(lblStatus));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
static class MyWindowListener implements WindowListener {
        private JTextArea lblStatus;
        public MyWindowListener(JTextArea lblStatus) {
            this.lblStatus = lblStatus;
        }
        public void windowOpened(WindowEvent e) {
            lblStatus.setText(lblStatus.getText() + "\r\n" + "windowOpened");
        }
        public void windowClosing(WindowEvent e) {
            JOptionPane.showMessageDialog(null, "windowClosing");
        }
        public void windowClosed(WindowEvent e) {
            JOptionPane.showMessageDialog(null, "windowClosed");
        }
        public void windowIconified(WindowEvent e) {
            lblStatus.setText(lblStatus.getText() + "\r\n" + "windowIconified");
        }
        public void windowDeiconified(WindowEvent e) {
            lblStatus.setText(lblStatus.getText() + "\r\n" + "windowDeiconified");
        }
        public void windowActivated(WindowEvent e) {
            lblStatus.setText(lblStatus.getText() + "\r\n" + "windowActivated");
        }
        public void windowDeactivated(WindowEvent e) {
            lblStatus.setText(lblStatus.getText() + "\r\n" + "windowDeactivated");
        }
    }
}
