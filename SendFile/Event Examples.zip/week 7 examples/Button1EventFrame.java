/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Button1EventFrame extends JFrame{
    
    JButton b1 = new JButton("Ok");
    JButton b2 = new JButton ("Cancel");
    public Button1EventFrame(){
        
        setLayout(new FlowLayout());
        add(b1);
        add(b2);
 
    ActionListener listener = new OKListener();
     b1.addActionListener(listener);
     b2.addActionListener(listener);
}

public static void main (String[] args){
       JFrame frame = new Button1EventFrame();
       frame.setVisible(true);
       frame.setSize(400, 400);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
}


class OKListener implements ActionListener {
    public void actionPerformed(ActionEvent e){
        
        
         if(e.getSource()==b1)
        System.out.println("it is OK");
        
         if(e.getSource()==b2)
             
            System.out.println("it is Cancel");
         
            }
            
}
}