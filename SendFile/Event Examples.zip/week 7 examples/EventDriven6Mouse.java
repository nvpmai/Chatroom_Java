/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class EventDriven6Mouse extends JApplet implements MouseListener
{
JPanel po;
JButton tf;

public void init()
{
po = new JPanel();
getContentPane().add(po);
tf=new JButton("OK");
po.add(tf);
tf.addMouseListener(this);
}

public void mousePressed(MouseEvent e)
{
showStatus("Mouse Key Pressed");
}

public void mouseReleased(MouseEvent e)
{
showStatus(" Mouse Key Released");
}	
public void mouseEntered(MouseEvent e)
{
showStatus(" mouse entered");
}
public void mouseExited(MouseEvent e)
{
showStatus(" mouse come out");
}
public void mouseClicked(MouseEvent e)
{
showStatus(" mouse click action happen");
}
}
//<applet code="Mkey" width=400 height=400>
//</applet>
