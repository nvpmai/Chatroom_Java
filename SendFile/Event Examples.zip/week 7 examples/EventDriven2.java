/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class EventDriven2 extends JApplet implements ActionListener
{
JPanel po;
JButton b1,b2;

public void init()
{
po = new JPanel();
getContentPane().add(po);
b1=new JButton("Blue");
b2=new JButton("Green");
po.add(b1);
po.add(b2);
b1.addActionListener(this);
b2.addActionListener(this);
}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
{
po.setBackground(Color.blue);
}
if(e.getSource()==b2)
{
po.setBackground(Color.green);
}
}
}