/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class EventDriven1 extends JApplet implements ActionListener
{
JPanel po;
JButton b1;

public void init()
{
po = new JPanel();
getContentPane().add(po);
b1=new JButton("Blue");

po.add(b1);
b1.addActionListener(this);
}

public void actionPerformed(ActionEvent e)
{
e.getSource();
po.setBackground(Color.blue);
}
}