/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TestEvents3Focus extends JApplet {
    public void init() {
        JLabel lblStatus = new JLabel();
        JButton btn1 = new JButton("Button 1");
        JButton btn2 = new JButton("Button 2");
        setLayout(new FlowLayout());
        add(btn1);
        add(btn2);
        add(lblStatus);
        btn1.addFocusListener(new MyFocusListener(lblStatus));
    }

    static class MyFocusListener implements FocusListener {
        private JLabel lblStatus;
        public MyFocusListener(JLabel lblStatus) {
            this.lblStatus = lblStatus;
        }

        public void focusGained(FocusEvent e) {
            lblStatus.setText("Focused gained");
        }

        public void focusLost(FocusEvent e) {
            lblStatus.setText("Focused lost");
        }
    }
}

