/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TestEvents extends JApplet {

    public void init() {
        JTextArea lblStatus = new JTextArea();
        JButton btn = new JButton("Play Video");
        btn.addMouseListener(new MyMouseListener(lblStatus));
        add(btn, BorderLayout.NORTH);
        add(lblStatus);
    }
static class MyMouseListener implements MouseListener {

        private JTextArea lblStatus;
        public MyMouseListener(JTextArea lblStatus) {
            this.lblStatus = lblStatus;
        }
        private void display(String action) {
            lblStatus.setText(lblStatus.getText() + "\r\n" + action);
        }
        public void mouseEntered(MouseEvent e) {
            display("entered");
        }
        public void mousePressed(MouseEvent e) {
            display("pressed");
        }
        public void mouseReleased(MouseEvent e) {
            display("released");
        }
        public void mouseClicked(MouseEvent e) {
            display("clicked");
        }
        public void mouseExited(MouseEvent e) {
            display("exited");
        }
    }
}

