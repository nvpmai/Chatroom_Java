/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class EventDriven5KeyPressed extends JApplet implements KeyListener
{
JPanel po;
JTextField tf;

public void init()
{
po = new JPanel();
getContentPane().add(po);
tf=new JTextField(20);
po.add(tf);
tf.addKeyListener(this);
}

public void keyPressed(KeyEvent e)
{
showStatus("Key Pressed");
}

public void keyReleased(KeyEvent e)
{
showStatus("you have not typed");
}	
public void keyTyped(KeyEvent e)
{
showStatus("Character typed ");
}

}
