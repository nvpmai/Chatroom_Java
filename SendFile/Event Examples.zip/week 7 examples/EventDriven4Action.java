/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author v90207
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EventDriven4Action extends JApplet implements ActionListener
{
JPanel panel1;
JButton b1,b2,b3;
String msg="";

public void init()
{
panel1 = new JPanel();
getContentPane().add(panel1);

b1=new JButton("Blue");
b2=new JButton("Green");
b3=new JButton("Yellow");

panel1.add(b1);
panel1.add(b2);
panel1.add(b3);

b1.addActionListener(this);
b2.addActionListener(this);
b3.addActionListener(this);
}

public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
	{
	setForeground(Color.yellow);				
	panel1.setBackground(Color.blue);
	msg="You Pressed Button b1";
	}
		
	if(e.getSource()==b2)
	{
	panel1.setBackground(Color.green);
	msg="You Pressed Button b2";
	}
		
	if(e.getSource()==b3)
	{
	panel1.setBackground(Color.yellow);
	msg="You Pressed Button b3";
	}
	repaint();
	}
 	
	public void paintComponent(Graphics g)
	{
                 super.paint(g);
                 g.setColor(Color.WHITE);
		g.drawString(msg,12,118);
 	}
}


